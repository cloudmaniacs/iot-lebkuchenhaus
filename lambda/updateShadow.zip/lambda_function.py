import json, boto3, os

region = os.environ['AWS_REGION']

def lambda_handler(event, context):
    
    if "body" in event:
    
        data = json.loads(event["body"])
        
        if "thingname" in data:
        
            thingname = data['thingname']
            
            r = data['r']
            g = data['g']
            b = data['b']
            brightness = data['brightness']
            
            relais1 = data['relais1']
            relais2 = data['relais2']
        
            client = boto3.client('iot-data', region_name=region)
            
            payload = json.dumps({"state": {"desired": {"lights": {"r": r, "g": g, "b": b, "brightness": brightness}, "relais": {"relais1": relais1, "relais2": relais2}}}})
            
            response = client.update_thing_shadow(thingName=thingname, payload=payload)
        
            return {
                'statusCode': 200,
                'body': 'OK'
            }
            
        else:
    
            return {
                'statusCode': 200,
                'body': 'Missing parameter!'
            }
            
    else:

        return {
            'statusCode': 200,
            'body': 'Invalid request!'
        }