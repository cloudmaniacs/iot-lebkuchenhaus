import json, boto3, os

region = os.environ['AWS_REGION']


def lambda_handler(event, context):
    
    if "queryStringParameters" in event:
    
        parameters = event['queryStringParameters']
        
        if "thing" in parameters:
            
            thingname = parameters['thing']
        
            client = boto3.client('iot-data', region_name=region)
            
            response = client.get_thing_shadow(thingName=thingname)
            
            streamingBody = response["payload"]
            jsonState = json.loads(streamingBody.read())
        
            return {
                'statusCode': 200,
                'body': json.dumps(jsonState["state"]["reported"])
            }
            
        else:
            
            return {
                'statusCode': 200,
                'body': 'Missing parameter!'
            }
            
    else:
            
        return {
            'statusCode': 200,
            'body': 'IoT Center'
        }